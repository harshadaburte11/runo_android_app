package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Personal_Loan_List extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_loan_list);
    }
}