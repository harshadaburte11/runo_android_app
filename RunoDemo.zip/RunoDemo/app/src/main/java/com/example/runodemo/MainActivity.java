package com.example.runodemo;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        btn_login=findViewById(R.id.btn_login);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLoginClicked(v);
            }
        });
    }

    public void onForgotPasswordClicked(View v) {

        Toast.makeText(this, "Forgot Password clicked", Toast.LENGTH_SHORT).show();
    }

    public void onChangeMobileClicked(View v) {
        Toast.makeText(this, "Change Mobile Number clicked", Toast.LENGTH_SHORT).show();
    }

    public void onLoginClicked(View v) {
        EditText etMobileNumber = findViewById(R.id.et_mobile_number);
        EditText etPassword = findViewById(R.id.et_password);

        String mobileNumber = etMobileNumber.getText().toString();
        String password = etPassword.getText().toString();

        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, Menupage.class);
        startActivity(intent);
    }

    public void onSignUpClicked(View v) {
        Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show();
    }

    public void onTermsClicked(View v) {
        Toast.makeText(this, "Terms and Conditions clicked", Toast.LENGTH_SHORT).show();
    }
}
