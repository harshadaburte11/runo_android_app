package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Basic_report extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_report);
    }
}