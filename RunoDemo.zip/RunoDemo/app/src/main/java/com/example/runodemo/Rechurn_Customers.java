package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.DatePicker;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.*;
import java.util.Calendar;

public class Rechurn_Customers extends AppCompatActivity {
    ImageView textViewFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rechurn_customers);

        textViewFilter=findViewById(R.id.textViewFilter);

        textViewFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
            }
        });
    }
    public void goBack() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Filter.class);
        startActivity(intent);
    }

}
