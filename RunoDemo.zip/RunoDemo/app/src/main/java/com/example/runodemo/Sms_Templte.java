package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Sms_Templte extends AppCompatActivity {

     TextView txtRingCust,txtDocList;
    ImageView imagePlus;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_templte);
        txtDocList=findViewById(R.id.txtDocList);
        txtRingCust=findViewById(R.id.txtRingCust);

        imagePlus=findViewById(R.id.imagePlus);

        txtDocList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewList();
            }
        });

        txtRingCust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewCust();
            }
        });

        imagePlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickPlus();
            }
        });
    }

    public void viewList() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Document_List.class);
        startActivity(intent);
    }

    public void viewCust() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Ringing_Customer_Loan_Offer.class);
        startActivity(intent);
    }

    public void clickPlus() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Sms_Template.class);
        startActivity(intent);
    }
}