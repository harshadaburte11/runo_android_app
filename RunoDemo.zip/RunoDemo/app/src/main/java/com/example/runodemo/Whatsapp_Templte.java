package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Whatsapp_Templte extends AppCompatActivity {

    TextView txtRingingCust,txtReferrenceMsg,txtPersonalLoan;
    ImageView imagePlus;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whatsapp_templte);

        txtRingingCust=findViewById(R.id.txtRingingCust);
        txtReferrenceMsg=findViewById(R.id.txtReferrenceMsg);
        txtPersonalLoan=findViewById(R.id.txtPersonalLoan);
        imagePlus=findViewById(R.id.imagePlus);

        txtRingingCust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ringingCustomer();
            }
        });

        txtReferrenceMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                referrenceMsg();
            }
        });

        txtPersonalLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loanList();
            }
        });

        imagePlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickPlus();
            }
        });
    }

    public void loanList() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Personal_Loan_List.class);
        startActivity(intent);
    }

    public void referrenceMsg() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, referrence_Message.class);
        startActivity(intent);
    }

    public void ringingCustomer() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Ringing_cust_offer_loan.class);
        startActivity(intent);
    }

    public void clickPlus() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, WhatsApp_Template.class);
        startActivity(intent);
    }
}