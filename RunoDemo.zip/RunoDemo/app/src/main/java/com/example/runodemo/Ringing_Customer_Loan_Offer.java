package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Ringing_Customer_Loan_Offer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ringing_customer_loan_offer);
    }
}