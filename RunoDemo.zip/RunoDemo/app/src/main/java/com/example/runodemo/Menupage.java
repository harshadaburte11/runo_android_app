package com.example.runodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.widget.*;
import android.view.View;
import android.os.Bundle;
import android.content.Intent;

public class Menupage extends AppCompatActivity {

    TextView textViewCallTrackAssist,textViewSetting,textViewChangePassword,textViewContactSupport;
    ImageView imgFollowups,imgReport,imgWhatsapp,imgSms,imgRecurring,imgRechurn,imgInteraction,imgEmail;
    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menupage);

        textViewCallTrackAssist = findViewById(R.id.textViewCallTrackAssist);
        textViewSetting=findViewById(R.id.textViewSetting);
        textViewChangePassword=findViewById(R.id.textViewChangePassword);
        textViewContactSupport=findViewById(R.id.textViewContactSupport);

        imgFollowups=findViewById(R.id.imgFollowups);
        imgReport=findViewById(R.id.imgReport);
        imgWhatsapp=findViewById(R.id.imgWhatsapp);
        imgSms=findViewById(R.id.imgSms);
        imgRecurring=findViewById(R.id.imgRecurring);
        imgRechurn=findViewById(R.id.imgRechurn);
        imgInteraction=findViewById(R.id.imgInteraction);
        imgEmail=findViewById(R.id.imgEmail);

        textViewCallTrackAssist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callTrack();
            }
        });

        textViewSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setting();
            }
        });

        textViewChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changePass();
            }
        });

        textViewContactSupport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contactSupport();
            }
        });

        imgFollowups.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                followups();
            }
        });

        imgSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                smsClick();
            }
        });


        imgReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestReport();
            }
        });



        imgRechurn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rechurnClick();
            }
        });

        imgInteraction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                interactionsClick();
            }
        });

        imgWhatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whatsapp();
            }
        });

        imgRecurring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recurringClick();
            }
        });

        imgEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickEmail();
            }
        });

    }

    public void callTrack() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, CallTrack_Assist.class);
        startActivity(intent);
    }

    public void setting() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Setting.class);
        startActivity(intent);
    }

    public void changePass() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Reset_Pass.class);
        startActivity(intent);
    }

    public void contactSupport() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Chatting.class);
        startActivity(intent);
    }

    public void followups() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Followups.class);
        startActivity(intent);
    }

    public void requestReport() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Basic_report.class);
        startActivity(intent);
    }

    public void whatsapp() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Whatsapp_Templte.class);
        startActivity(intent);
    }

    public void smsClick() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Sms_Templte.class);
        startActivity(intent);
    }

    public void recurringClick() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Recurring_Followups.class);
        startActivity(intent);
    }

    public void rechurnClick() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Rechurn_Customers.class);
        startActivity(intent);
    }

    public void interactionsClick() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Interactions.class);
        startActivity(intent);
    }

    public void clickEmail() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, Email_Template.class);
        startActivity(intent);
    }
}