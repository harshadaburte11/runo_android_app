package com.example.runo.ui.menu;

import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.runo.Calltrack_Assist;
import com.example.runo.Change_Pass;
import com.example.runo.Contact_Support;
import com.example.runo.R;
import com.example.runo.Setting;

public class MenuFragment extends Fragment {

    private MenuViewModel mViewModel;
    TextView textViewCallTrackAssist,textViewSetting,textViewChangePassword,textViewContactSupport;

    public static MenuFragment newInstance() {
        return new MenuFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_menu, container, false);
        textViewCallTrackAssist = rootView.findViewById(R.id.textViewCallTrackAssist);
        textViewSetting = rootView.findViewById(R.id.textViewSetting);
        textViewContactSupport=rootView.findViewById(R.id.textViewContactSupport);

        textViewCallTrackAssist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Calltrack_Assist.class);
                startActivity(intent);
            }
        });

        textViewSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Setting.class);
                startActivity(intent);
            }
        });

        textViewChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Change_Pass.class);
                startActivity(intent);
            }
        });

        textViewContactSupport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Contact_Support.class);
                startActivity(intent);
            }
        });

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(MenuViewModel.class);
        // TODO: Use the ViewModel
    }

}