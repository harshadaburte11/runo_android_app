package com.example.runo.ui.call;

import androidx.lifecycle.ViewModel;

public class CallViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}