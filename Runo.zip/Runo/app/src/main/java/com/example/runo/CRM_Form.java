package com.example.runo;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.os.Bundle;
import android.widget.LinearLayout;

public class CRM_Form extends AppCompatActivity {

    private boolean isFormVisible = false;
    private LinearLayout collapsibleForm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crm_form);

        collapsibleForm = findViewById(R.id.collapsibleForm);
    }
    public void toggleFormVisibility(View view) {
        if (isFormVisible) {
            collapsibleForm.setVisibility(View.GONE);
        } else {
            collapsibleForm.setVisibility(View.VISIBLE);
        }
        isFormVisible = !isFormVisible;
    }
}