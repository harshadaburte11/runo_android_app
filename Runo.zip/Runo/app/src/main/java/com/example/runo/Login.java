package com.example.runo;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.runo.ui.home.HomeFragment;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
    }

    public void onForgotPasswordClicked(View view) {

        Toast.makeText(this, "Forgot Password clicked", Toast.LENGTH_SHORT).show();
    }

    public void onChangeMobileClicked(View view) {
        // Handle change mobile number click
        // Open change mobile number activity or perform necessary action
        Toast.makeText(this, "Change Mobile Number clicked", Toast.LENGTH_SHORT).show();
    }

    public void onLoginClicked(View view) {
        // Handle login click
        EditText etMobileNumber = findViewById(R.id.et_mobile_number);
        EditText etPassword = findViewById(R.id.et_password);

        String mobileNumber = etMobileNumber.getText().toString();
        String password = etPassword.getText().toString();

        // Perform validation and login authentication here

        // Dummy success message
        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, HomeFragment.class);
        startActivity(intent);
    }

    public void onSignUpClicked(View view) {
        // Handle sign up click
        // Open sign up activity or perform necessary action
        Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show();
    }

    public void onTermsClicked(View view) {
        // Handle terms and conditions click
        // Open terms and conditions page or perform necessary action
        Toast.makeText(this, "Terms and Conditions clicked", Toast.LENGTH_SHORT).show();
    }
}
