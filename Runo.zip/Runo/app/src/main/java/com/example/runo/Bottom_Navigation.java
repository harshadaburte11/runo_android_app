package com.example.runo;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.runo.ui.allocation.AllocationFragment;
import com.example.runo.ui.call.CallFragment;
import com.example.runo.ui.customer.CustomerFragment;
import com.example.runo.ui.home.HomeFragment;
import com.example.runo.ui.menu.MenuFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Bottom_Navigation extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment = new HomeFragment();
    AllocationFragment allocationFragment = new AllocationFragment();
    CustomerFragment customerFragment = new CustomerFragment();
    CallFragment callFragment = new CallFragment();
    MenuFragment menuFragment = new MenuFragment();
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation);
        toolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("one");

        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.home);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_nav_menu, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.home:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.ourFragment, homeFragment)
                        .commit();
                return true;
            case R.id.allocation:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.ourFragment, allocationFragment)
                        .commit();
                return true;
            case R.id.customer:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.ourFragment, customerFragment)
                        .commit();
                return true;
            case R.id.call:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.ourFragment, callFragment)
                        .commit();
                return true;
            case R.id.menu:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.ourFragment, menuFragment)
                        .commit();
                return true;
        }
        return false;
    }
}