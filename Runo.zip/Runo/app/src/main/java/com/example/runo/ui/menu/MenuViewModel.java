package com.example.runo.ui.menu;

import androidx.lifecycle.ViewModel;

public class MenuViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}