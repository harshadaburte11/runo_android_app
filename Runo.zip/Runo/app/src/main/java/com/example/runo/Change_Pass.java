package com.example.runo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.runo.ui.menu.MenuFragment;

public class Change_Pass extends AppCompatActivity {

    TextView textViewGoBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pass);

        textViewGoBack=findViewById(R.id.textViewGoBack);

        textViewGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
            }
        });

    }
    public void goBack() {
        // Create an Intent to start a new activity or perform any desired action
        Intent intent = new Intent(this, MenuFragment.class);
        startActivity(intent);
    }
}