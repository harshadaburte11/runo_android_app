package com.example.runo.ui.allocation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AllocationViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public AllocationViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is allocation fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}