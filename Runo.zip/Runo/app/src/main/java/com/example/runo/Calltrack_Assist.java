package com.example.runo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Calltrack_Assist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calltrack_assist);
    }
}